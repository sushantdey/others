package com.cg.project.test;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.mathservices.MathServices;
import com.cg.project.mathservices.MathServicesImpl;
public class MathServicesTest {
	static MathServices mathServices;
	@BeforeClass
	public static void setUPTestEnv(){
		mathServices = new MathServicesImpl();
	}
	@Before
	public void setUpMockDataForTest(){
		
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForFirstNOInvalid() throws InvalidNumberRangeException{
		mathServices.addNum(-100,200);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForSecondNOInvalid() throws InvalidNumberRangeException{
		mathServices.addNum(100,-200);
	}
	@Test()
	public void testAddNumbersForBothValidNO() throws InvalidNumberRangeException{
		int expectedAns=300;
		int actualAns=mathServices.addNum(100,200);
		Assert.assertEquals(expectedAns, actualAns);
	}
	@After
	public void tearDownMockDataForTest(){
		System.out.println("tearDownMockDataForTest()");
	}
	@AfterClass
	public static void tearDownSetUPTestEnv(){
		mathServices=null;
	}
}
