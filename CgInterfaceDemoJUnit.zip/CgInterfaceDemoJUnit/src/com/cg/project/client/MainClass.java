package com.cg.project.client;
import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.mathservices.MathServices;
import com.cg.project.mathservices.MathServicesImpl;
public class MainClass {
	public static void main(String[] args) throws InvalidNumberRangeException {
		MathServices service = new MathServicesImpl();
		System.out.println(service.addNum(12, 24));
		service.subNum(-24, 12);
		System.out.println(service);
	}
}
