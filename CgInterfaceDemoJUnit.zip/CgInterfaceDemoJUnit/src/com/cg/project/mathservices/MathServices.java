package com.cg.project.mathservices;
import com.cg.project.exceptions.InvalidNumberRangeException;
public interface MathServices {
	public abstract int addNum(int num1,int num2) throws InvalidNumberRangeException;
	abstract int subNum(int num1,int num2)throws InvalidNumberRangeException;
	int  mulNum(int num1,int num2)throws InvalidNumberRangeException;
}
