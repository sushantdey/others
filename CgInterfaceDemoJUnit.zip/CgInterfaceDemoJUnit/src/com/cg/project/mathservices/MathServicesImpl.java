package com.cg.project.mathservices;

import com.cg.project.exceptions.InvalidNumberRangeException;

public class MathServicesImpl implements MathServices {
	@Override
	public int addNum(int num1, int num2) throws InvalidNumberRangeException{
		if(num1<0 || num2<0)throw new InvalidNumberRangeException("Enter number greater than 0");
		return num1+num2;
	}
	@Override
	public int subNum(int num1, int num2) throws InvalidNumberRangeException {
		if(num1<0 || num2<0)throw new InvalidNumberRangeException("Enter number greater than 0");
		return num1-num2;
	}
	@Override
	public int mulNum(int num1, int num2) throws InvalidNumberRangeException {
		if(num1<0 || num2<0)throw new InvalidNumberRangeException("Enter number greater than 0");
		return num1*num2;
	}
}
