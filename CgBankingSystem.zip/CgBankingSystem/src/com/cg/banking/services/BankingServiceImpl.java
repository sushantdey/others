package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.User;
import com.cg.banking.daoservices.BankingDAO;
import com.cg.banking.daoservices.BankingDAOImpl;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
public class BankingServiceImpl implements BankingService{
	private static final Logger logger = Logger.getLogger(BankingServiceImpl.class);
	private BankingDAO bankingDao=new BankingDAOImpl();
	@Override
	public long openAccount(String customerName,String emailId, String address,String pancard,String accountType,float accountBalance,String securityAnswer)
			throws BankingServicesDownException {

		int  randomNumber=(int) ((Math.random()*((9999-1000)+1))+1000);
		String fixedString="Abcd";
		String loginPassword=fixedString+randomNumber;

		randomNumber=(int) ((Math.random()*((9999-1000)+1))+1000);
		String pinNumber=""+randomNumber;

		Customer customer=new Customer(customerName,emailId,address,pancard,new User(loginPassword,securityAnswer,pinNumber));

		Account account=new Account(accountType,accountBalance,customer);
		List<Account> listAccount=new ArrayList<Account>();
		listAccount.add(account);
		customer.setAccounts(listAccount);

		Transaction transaction=new Transaction(accountBalance,"credit",account);
		List<Transaction> listTransaction=new ArrayList<Transaction>();
		listTransaction.add(transaction);
		account.setTransaction(listTransaction);
		customer=bankingDao.save(customer);
		logger.info("Customer Registered with CustomerId "+customer.getCustomerId());
		return customer.getCustomerId();
	}
	@Override
	public float depositAmount(long accountNo,float amount)
			throws AccountNotFoundException, BankingServicesDownException
	{

		Account account=bankingDao.findAccountNo(accountNo);
		if(account==null){
			logger.error("Transaction Failed");
			throw new AccountNotFoundException();
		}
		bankingDao.update(accountNo,account.getAccountBalance()+amount);

		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setAmount(amount);
		transaction.setTransactionType("credit");
		bankingDao.save(transaction);
		logger.info("Deposit Successful for Account Number "+accountNo);
		return 0;
	}
	@Override
	public float withdrawAmount(long accountNo,float amount)
			throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException
	{
		Account account=bankingDao.findAccountNo(accountNo);
		if(account==null){
			logger.error("Transaction Failed");
			throw new AccountNotFoundException();
		}
		if(account.getAccountBalance()-amount<1000){
			logger.error("Transaction Failed");
			throw new InsufficientAmountException();
		}
		bankingDao.update(accountNo,account.getAccountBalance()-amount);
		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setAmount(amount);
		transaction.setTransactionType("debit");
		bankingDao.save(transaction);
		logger.info("Withdraw Successful for Account Number "+accountNo);
		return 0;
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount)
					throws InsufficientAmountException, AccountNotFoundException,
					BankingServicesDownException{
		//--- Withdraw From -------------
		Account accountFrom=bankingDao.findAccountNo(accountNoFrom);
		Account accountTo=bankingDao.findAccountNo(accountNoTo);
		if(accountFrom==null || accountTo==null){
			logger.error("Transaction Failed");
			throw new AccountNotFoundException();
		}
		if(accountFrom.getAccountBalance()-transferAmount<1000){
			logger.error("Transaction Failed");
			throw new InsufficientAmountException();
		}
		bankingDao.update(accountNoFrom,accountFrom.getAccountBalance()+transferAmount);
		Transaction transaction=new Transaction();
		transaction.setAccount(accountFrom);
		transaction.setAmount(transferAmount);
		transaction.setTransactionType("debit");
		bankingDao.save(transaction);
		//--Deposit To--------------------------------
		bankingDao.update(accountNoTo,accountTo.getAccountBalance()-transferAmount);
		transaction=new Transaction();
		transaction.setAccount(accountTo);
		transaction.setAmount(transferAmount);
		transaction.setTransactionType("credit");
		bankingDao.save(transaction);
		logger.info("Fund transfer Successful from Account Number "+accountNoFrom+" to Account Number "+accountNoTo);
		return true;
	}
	@Override
	public Customer getCustomerDetails(long customerId)
			throws AccountNotFoundException, BankingServicesDownException {
		Customer customer =bankingDao.findCustomer(customerId);
		if(customer==null)
			throw new AccountNotFoundException();
		return customer;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transactionList=bankingDao.getTransactions(accountNo);
		if(transactionList.isEmpty())
			throw new AccountNotFoundException();
		return transactionList;
	}
	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
		List<Account> accountList=bankingDao.findAllAccountDetails();
		return accountList;
	}
	@Override
	public List<Transaction> getAllTransactionDetails()
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transactionList=bankingDao.findAllTransactionDetails();
		return transactionList;
	}
	@Override
	public List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException, AccountNotFoundException {
		List<Customer> accountList=bankingDao.findAllCustomerDetails();
		return accountList;
	}
}
