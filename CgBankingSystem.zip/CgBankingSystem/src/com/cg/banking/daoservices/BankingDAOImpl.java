package com.cg.banking.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public class BankingDAOImpl implements BankingDAO{
	EntityManagerFactory factory1=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Account save(Account account) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);																				//Data to be saved into the table of database..
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}
	@Override
	public Customer save(Customer customer) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);																				//Data to be saved into the table of database..
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer;
	}
	@Override
	public Transaction save(Transaction transaction) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);																				//Data to be saved into the table of database..
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}
	@Override
	public Account findAccountNo(long accountNo) {
		EntityManager entityManager=factory1.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	}
	@Override
	public void update(long accountNo, float f) {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
		Account account1=entityManager.find(Account.class, accountNo);
		account1.setAccountBalance(f);
		entityManager.getTransaction().commit();
	}
	@Override
	public Customer findCustomer(long customerId) {
		EntityManager entityManager=factory1.createEntityManager();
		return entityManager.find(Customer.class, customerId);
	}
	@Override
	public List<Transaction> getTransactions(long accountNo) {
		EntityManager entityManager=factory1.createEntityManager();		
		entityManager.getTransaction().begin();
	    @SuppressWarnings("unchecked")
		List<Transaction> listTransactions = entityManager.createQuery("SELECT t FROM Transaction t where accountno="+accountNo).getResultList();
		return listTransactions;
	}
	@Override
	public List<Account> findAllAccountDetails() {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
	    @SuppressWarnings("unchecked")
		List<Account> listAccounts = entityManager.createQuery("SELECT a FROM Account a").getResultList();
		return listAccounts;
	}
	@Override
	public List<Transaction> findAllTransactionDetails() {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
	    @SuppressWarnings("unchecked")
		List<Transaction> listTransactions = entityManager.createQuery("SELECT t FROM Transaction  t").getResultList();
		return listTransactions;
	}
	@Override
	public List<Customer> findAllCustomerDetails() {
		EntityManager entityManager=factory1.createEntityManager();
		entityManager.getTransaction().begin();
	    @SuppressWarnings("unchecked")
		List<Customer> listCustomer = entityManager.createQuery("SELECT c FROM Customer  c").getResultList();
		return listCustomer;
	}	
}