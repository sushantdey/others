<?php

$bidRequestJsonStr = file_get_contents('php://input');
$bidRequestJson = json_decode($bidRequestJsonStr,true);

//print_r($bidRequestJson);die;

//if(isset($bidRequestJson['imp'][0]['ext']['adtype']) && $bidRequestJson['imp'][0]['ext']['adtype']=='native')
//if(isset($bidRequestJson['imp'][0]['ext'][0]['adtype']))
//{
//echo "IN NATIVE";
//$adType='native';
//$ad="%3C%3Fxml%20version%3D%221.0%22%20encoding%3D%22UTF-8%22%3F%3E%3Cad%20id%3D%2212345%22%3E%3CdisplayName%3EPet%20Rescue%3C%2FdisplayName%3E%3CshortMessage%3EPut%20your%20pet-saving%20skills%20to%20the%20test%3C%2FshortMessage%3E%3CfullMessage%3EAre%20you%20ready%20for%20some%20pet-tastic%20fun%3F%20The%20hit%20puzzle%20game%20Pet%20Rescue%20Saga%20is%20available%20to%20play%20on%20Facebook%2C%20smartphone%20and%20tablet%20devices.%3C%2FfullMessage%3E%3CadSponsoredMarker%3ESponsored%3C%2FadSponsoredMarker%3E%3Cicon%3E%3Cimage%20width%3D%22100%22%20height%3D%22100%22%3Ehttp%3A%2F%2Fadmarvel.s3.amazonaws.com%2Fimages%2Ficon_image.jpg%3C%2Fimage%3E%3C%2Ficon%3E%3CcampaignImage%3E%3Cimage%20width%3D%22960%22%20height%3D%22640%22%3Ehttp%3A%2F%2Fadmarvel.s3.amazonaws.com%2Fimages%2Fcampaign_image.jpg%3C%2Fimage%3E%3C%2FcampaignImage%3E%3Ccta%20action%3D%22install%22%3E%3Ctitle%3EInstall%20App%3C%2Ftitle%3E%3CclickUrl%3Ehttp%3A%2F%2Fpetrescuesaga.com%2F%3C%2FclickUrl%3E%3C%2Fcta%3E%3Ctrackers%3E%3Ctracker%20typ//e%3D%22click%22%3E%3Curl%3Ehttps%3A%2F%2Fwww.google.co.in%2F%3Fgws_rd%3Dssl%3C%2Furl%3E%3C%2Ftracker%3E%3Ctracker%20type%3D%22impression%22%3E%3Curl%3Ehttps%3A%2F%2Fwww.google.co.in%2F%3Fgws_rd%3Dssl%3C%2Furl%3E%3C%2Ftracker%3E%3C%2Ftrackers%3E%3Cmetadatas%3E%3Cmetadata%20type%3D%22string%22%20key%3D%22appDeveloperName%22%20value%3D%22Pet%20Rescue%22%20%2F%3E%3Cmetadata%20type%3D%22xml%22%20key%3D%22rating%22%3E%3C!%5BCDATA%5B%3Crating%20value%3D%223.5%22%20base%3D%225%22%3E%3Ccomplete%3E%3Cimage%20width%3D%2220%22%20height%3D%2230%22%3Ehttp%3A%2F%2Fadmarvel.s3.amazonaws.com%2Fimg%2Fstars%2Fblue%2F3.png%3C%2Fimage%3E%3C%2Fcomplete%3E%3Chalf%3E%3Cimage%20width%3D%2220%22%20height%3D%2230%22%3Ehttp%3A%2F%2Fadmarvel.s3.amazonaws.com%2Fimg%2Fstars%2Fblue%2F0.5.png%3C%2Fimage%3E%3C%2Fhalf%3E%3Cfull%3E%3Cimage%20width%3D%2220%22%20height%3D%2230%22%3Ehttp%3A%2F%2Fadmarvel.s3.amazonaws.com%2Fimg%2Fstars%2Fblue%2F1.png%3C%2Fimage%3E%3C%2Ffull%3E%3C%2Frating%3E%5D%5D%3E%3C%2Fmetadata%3E%3C%2Fmetadatas%3E%3C%2Fad%3E"//;

//}

if (isset($bidRequestJson['imp'][0]['video']))
{
	$adType = "video";
        $ad="%3C%3Fxml%20version%3D%221.0%22%20encoding%3D%22UTF-8%22%20standalone%3D%22no%22%3F%3E%20%3CVAST%20xmlns%3Axsi%3D%22http%3A%2F%2Fwww.w3.org%2F2001%2FXMLSchema-instance%22%20version%3D%222.0%22%20xsi%3AnoNamespaceSchemaLocation%3D%22vast.xsd%22%3E%20%3CAd%20id%3D%2212345678%22%3E%20%3CInLine%3E%20%3CAdSystem%3EBrightRoll%3C%2FAdSystem%3E%20%3CAdTitle%2F%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fview.atdmt.com%2FRGA%2Fview%2F204908871%2Fdirect%2F01%2F%3Bshoes%3Bstart%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fbrxserv-21.btrll.com%2Fv1%2Fepix%2F6835455%2F3855172%2F54%2F193%2FMbNvKdkgBkAABTDC_vAAAANgAAAMEAOtNEAAAAAAAbAvK-sLEHWA%2Fevent.imp%2Fr_64.aHR0cDovL2Iuc2NvcmVjYXJkcmVzZWFyY2guY29tL3A_YzE9MSZjMj02MDAwMDA2JmMzPSZjND1icngmYzU9MDEwMDAwJmM2PTY4MzU0NTUmYzEwPSZjQTE9OCZjQTI9NjAwMDAwNiZjQTM9NTQmY0E0PTM4NTUxNzImY0E1PTg1JmNBNj02ODM1NDU1JmNBMTA9MTkzJmN2PTEuNyZjaj0mcm49MTM5MzMwNzYzMSZyPWh0dHAlM0ElMkYlMkZwaXhlbC5xdWFudHNlcnZlLmNvbSUyRnBpeGVsJTJGcC1jYjZDMHpGRjdkV2pJLmdpZiUzRmxhYmVscyUzRHAuNjgzNTQ1NS4zODU1MTcyLjAlMkNhLjg1LjU0LjE5MyUyQ3UuOTY4LjB4MCUzQm1lZGlhJTNEYWQlM0JyJTNEMTM5MzMwNzYzMQ%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Ftest.btrll.com%2Funcached_pix%3Fimp_shoes%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fib.adnxs.com%2Fseg%3Fadd%3D362896%26t%3D2%26cb%3D1393307631%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Frc.rlcdn.com%2F361686.gif%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fs.innovid.com%2F1x1.gif%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dinit%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fs.innovid.com%2F1x1.gif%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dplay%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fb.scorecardresearch.com%2Fp%3Fc1%3D3%26c2%3D6000006%26c3%3Dmobile%26c4%3D193%26c5%3D54%26c11%3D3855172%26c12%3D%5Bcs_dpid%5D%26c13%3D320x181%26ns_ap_res%3D%5Bcs_screen_resolution%5D%26ns_ap_pl%3D%5Bbr_os%5D%26ns_ap_device%3D%5Bbr_model%5D%26ns_ap_lat%3D%5Bbr_lat%5D%26ns_ap_lon%3D%5Bbr_long%5D%26rn%3D1393307631653%26ax_fwd%3D1%26ax_publisher%3D3855172%26ax_pageurl%3D3855172%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fb.scorecardresearch.com%2Fp2%3Fc1%3D3%26c2%3D6000006%26c3%3D_e0_mobile%26c4%3D193%26c5%3D54%26c6%3D%5Bcustom_id%5D%26c11%3D3855172%26c13%3D1x1%26c16%3Dbr%26cj%26ns_ad_sv%3D%26ns_ad_event%3Dv_start%26ns_ad_sv%3Dflash_%5Bpartnerid%5D%26cs_nc%3D1%26ax_fw%3D1%26ns__t%3D1393307631656%5D%5D%3E%20%3C%2FImpression%3E%20%3CImpression%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fwww.google.com%5D%5D%3E%20%3C%2FImpression%3E%20%3CCreatives%3E%20%3CCreative%20id%3D%22193%22%20sequence%3D%221%22%3E%20%3CLinear%3E%20%3CDuration%3E00%3A00%3A30%3C%2FDuration%3E%20%3CTrackingEvents%3E%20%3CTracking%20event%3D%22firstQuartile%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fs.innovid.com%2F1x1.gif%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dvpoint%26event_id%3Dpercent%26event_value%3D25%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22midpoint%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fbrxserv-21.btrll.com%2Fv1%2Fepix%2F6835455%2F3855172%2F54%2F193%2FMbNvKdkgBkAABTDC_vAAAANgAAAMEAOtNEAAAAAAAbAvK-sLEHWA%2Fevent.mid%2Fr_64.aHR0cDovL3Rlc3QuYnRybGwuY29tL3VuY2FjaGVkX3BpeD9taWRfc2hvZXM%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22midpoint%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fview.atdmt.com%2FRGA%2Fview%2F204908871%2Fdirect%2F01%2F%3Bshoes%3Bmid%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22midpoint%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fs.innovid.com%2F1x1.gif%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dvpoint%26event_id%3Dpercent%26event_value%3D50%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22midpoint%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fb.scorecardresearch.com%2Fp2%3Fc1%3D3%26c2%3D6000006%26c3%3D_e0_mobile%26c4%3D193%26c5%3D54%26c6%3D%5Bcustom_id%5D%26c11%3D3855172%26c13%3D1x1%26c16%3Dbr%26cj%26ns_ad_sv%3D%26ns_ad_event%3Dv_midpoint%26ns_ad_sv%3Dflash_%5Bpartnerid%5D%26cs_nc%3D1%26ax_fw%3D1%26ns__t%3D1393307631676%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22thirdQuartile%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fs.innovid.com%2F1x1.gif%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dvpoint%26event_id%3Dpercent%26event_value%3D75%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22complete%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fbrxserv-21.btrll.com%2Fv1%2Fepix%2F6835455%2F3855172%2F54%2F193%2FMbNvKdkgBkAABTDC_vAAAANgAAAMEAOtNEAAAAAAAbAvK-sLEHWA%2Fevent.end%2Fr_64.aHR0cDovL3ZpZXcuYXRkbXQuY29tL1JHQS92aWV3LzIwNDkwODg3MS9kaXJlY3QvMDEvO3Nob2VzO2VuZA%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22complete%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Ftest.btrll.com%2Funcached_pix%3Fend_shoes%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22complete%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fs.innovid.com%2F1x1.gif%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dvpoint%26event_id%3Dpercent%26event_value%3D100%5D%5D%3E%20%3C%2FTracking%3E%20%3CTracking%20event%3D%22complete%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fb.scorecardresearch.com%2Fp2%3Fc1%3D3%26c2%3D6000006%26c3%3D_e0_mobile%26c4%3D193%26c5%3D54%26c6%3D%5Bcustom_id%5D%26c11%3D3855172%26c13%3D1x1%26c16%3Dbr%26cj%26ns_ad_sv%3D%26ns_ad_event%3Dv_complete%26ns_ad_sv%3Dflash_%5Bpartnerid%5D%26cs_nc%3D1%26ax_fw%3D1%26ns__t%3D1393307631691%5D%5D%3E%20%3C%2FTracking%3E%20%3C%2FTrackingEvents%3E%20%3CVideoClicks%3E%20%3CClickThrough%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fservice.innovid.com%2Fvclk%2Findex.php%3Fproject_hash%3D1hkge2%26client_id%3D440%26video_id%3D9655%26channel_id%3D3847%26publisher_id%3D440%26placement_tag_id%3D0%26project_state%3D2%26r%3D1393307631639%26action%3Dclktru%26click%3Dhttp%253A%252F%252Fwww.dior.com%5D%5D%3E%20%3C%2FClickThrough%3E%20%3CClickTracking%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fbrxserv-21.btrll.com%2Fv1%2Fepix%2F6835455%2F3855172%2F54%2F193%2FMbNvKdkgBkAABTDC_vAAAANgAAAMEAOtNEAAAAAAAbAvK-sLEHWA%2Fevent.c_trk%2Fr_64.aHR0cDovL3Rlc3QuYnRybGwuY29tL3VuY2FjaGVkX3BpeD9jbGtfc2hvZXM%5D%5D%3E%20%3C%2FClickTracking%3E%20%3CClickTracking%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fbrxserv-21.btrll.com%2Fv1%2Fepix%2F6835455%2F3855172%2F54%2F193%2FMbNvKdkgBkAABTDC_vAAAANgAAAMEAOtNEAAAAAAAbAvK-sLEHWA%2Fevent.click%2Fr_64.aHR0cDovL3d3dy5hZGNvdW5jaWwub3JnLw%5D%5D%3E%20%3C%2FClickTracking%3E%20%3C%2FVideoClicks%3E%20%3CMediaFiles%3E%20%3CMediaFile%20delivery%3D%22progressive%22%20type%3D%22video%2Fmp4%22%20bitrate%3D%22400%22%20height%3D%22181%22%20width%3D%22320%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fstatic.innovid.com%2Fassets%2F3743%2F78%2Fsource.mp4%5D%5D%3E%20%3C%2FMediaFile%3E%20%3C%2FMediaFiles%3E%20%3C%2FLinear%3E%20%3C%2FCreative%3E%20%3CCreative%20sequence%3D%221%22%3E%20%3CCompanionAds%3E%20%20%20%20%20%3C%2FCompanionAds%3E%20%3C%2FCreative%3E%20%3C%2FCreatives%3E%20%3CExtensions%3E%20%3CExtension%3E%20%3CAVID%3E%20%3CAdVerifications%3E%20%3CVerification%3E%20%3CJavaScriptResource%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fpixel.adsafeprotected.com%2Fjload%3FanId%3D923116%26advId%3Domcu1a0%26campId%3Di49xnsb%26chanId%3Dfoiuq5h%26placementId%3Dqplh7w46%26pubId%3Dhjz0fy6%26bidurl%3Dcom.peoplefun.wordcross%26uId%3Dnull%26impId%3D32f12c21-a8bd-4827-be76-63c2c18f94a2%26planId%3Domax%26adsafe_par%5D%5D%3E%20%3C%2FJavaScriptResource%3E%20%3C%2FVerification%3E%20%3C%2FAdVerifications%3E%20%3C%2FAVID%3E%20%3C%2FExtension%3E%20%3CExtension%20type%3D%22AdVerifications%22%3E%20%3CAdVerifications%3E%20%3CVerification%20vendor%3D%22integralads.com%22%3E%20%3CJavaScriptResource%20apiFramework%3D%22omid%22%20browserOptional%3D%22true%22%3E%20%3C%21%5BCDATA%5Bhttp%3A%2F%2Fpixel.adsafeprotected.com%2Fjload%3FanId%3D923116%26advId%3Domcu1a0%26campId%3Di49xnsb%26chanId%3Dfoiuq5h%26placementId%3Dqplh7w46%26pubId%3Dhjz0fy6%26bidurl%3Dcom.peoplefun.wordcross%26uId%3Dnull%26impId%3D32f12c21-a8bd-4827-be76-63c2c18f94a2%26planId%3Domax%26adsafe_par%5D%5D%3E%20%3C%2FJavaScriptResource%3E%20%3C%2FVerification%3E%20%3C%2FAdVerifications%3E%20%3C%2FExtension%3E%20%3C%2FExtensions%3E%20%3C%2FInLine%3E%20%3C%2FAd%3E%20%3C%2FVAST%3E";   
}
else
{
$adType = "banner";
$ad = "%3Ca+href%3D%22http%3A%2F%2Fwww.google.com%22+target%3D%22_self%22%3E%3Cimg+src%3D%22http%3A%2F%2Fadmarvel.s3.amazonaws.com%2Fads%2Fc26930%2F13981095221145_Ads_300x50.png%22+alt%3D%22%22+title%3D%22%22+border%3D%220%22+height%3D%2250%22+width%3D%22300%22%3E%3Cbr%3ERTB+Banner+Ad%3C%2Fa%3E";
//$ad = "<a href="http://www.google.com" target="_self"><img src="http://admarvel.s3.amazonaws.com/ads/c26930/13981095221145_Ads_300x50.png" alt="" title="" border="0" height="50" width="300"><br>RTB Banner Ad</a>";

}


$adContent = <<<EOT

{
    "id": "[BID_REQUEST_ID]",
    "seatbid": [
        {
            "bid": [
                {
                    "id": "1",
                    "impid": "1",
                    "price":[BID_PRICE],
                    "adid": "1",
                    "nurl":"https://www.google.com",
"lurl":"https://lossurl.com?reason=\${AUCTION_LOSS}",
"burl":"https://cognizant.com/billtest/014/bidder719Video?billnoticeurl=\${AUCTION_PRICE}&impid=\${AUCTION_IMP_ID}",


                    "adm":"[AD]",
		    "adomain": [
                        "auto2001.com","testinv.com","blockedatinventory2.com","allowedatdeal.com"
                    ],
 		"cat": [
                        "IAB1-2"
                    ],
"w":"300",
"h":"50",
"wratio":"300",
"hratio":"50",
"bundle":"com.resun.chantingvedas1","language":"en","exp":20,
                    "iurl": "https://www.embeda.com.tw/en/wp-content/uploads/2013/01/Facebook-logo-300x300.png",
                    "cid": "TestBidder719VideoCampaign",
                    "crid": "TestBidder719Videocreative",
                    [DEAL_ID_ATTR]
                    "attr": [
                        1,
                        2,
                        3,
                        4,
                        5,
                        6,
                        7,
                        12

                    ]
                }
            ],
            "seat": "512"
        }
    ],
    "bidid": "abc1123",
    "cur": "USD"
}
EOT;

$floorPrice = isset($bidRequestJson['imp'][0]['pmp']['deals'][0]['bidfloor'])?$bidRequestJson['imp'][0]['pmp']['deals'][0]['bidfloor']:$bidRequestJson['imp'][0]['bidfloor'];

//$bidPrice = rand($floorPrice+1,$floorPrice+5);
$bidPrice = 10.0;
$adContent = str_replace("[BID_PRICE]",$bidPrice,$adContent);
//echo json_encode($bidRequestJson);
$adContent = str_replace("[BID_REQUEST_ID]",isset($bidRequestJson["id"])?$bidRequestJson["id"]:"1234567890",$adContent);
$adContent = str_replace("[AD]",$ad,$adContent);

if(isset($bidRequestJson['imp'][0]['pmp']))
{
	$adContent = str_replace("[DEAL_ID_ATTR]","\"dealid\": \"".$bidRequestJson['imp'][0]['pmp']['deals'][0]['id']."\",",$adContent);
}
else
{
	$adContent = str_replace("[DEAL_ID_ATTR]","",$adContent);
}

error_log("\n".date('Ymd H:i:s')."BID_REQUEST_ID : ".$bidRequestJson["id"]." ; BID_FLOOR : ".$bidRequestJson['imp'][0]['bidfloor']."; AD_TYPE : $adType ; BID_PRICE : $bidPrice ; BID_REQUEST : $bidRequestJsonStr ; BID_RESPONSE : $adContent",3,"/mnt/log/httpd/bidder536.log");
error_log("\n Request : $bidRequestJsonStr \n Response : $adContent",3,"/mnt/log/httpd/bidder536.log");
echo "$adContent";


?>
