package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerRegistrationStepDefinition {
	@Given("^User is on Customer registration page$")
	public void user_is_on_Customer_registration_page() throws Throwable {
	    
	}

	@When("^User enters valid registration details$")
	public void user_enters_valid_registration_details() throws Throwable {
	    
	}

	@Then("^Display Registration successful page$")
	public void display_Registration_successful_page() throws Throwable {
	    
	}
}
